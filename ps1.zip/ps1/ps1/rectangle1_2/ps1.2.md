# Problem Statement
1.2 Define a class Rectangle with its length and breadth. Follow the below steps,

 1. Provide appropriate constructor(s), which gives facility of constructing Rectangle object with default values of length and breadth as 0 or passing value of length and breadth externally to constructor.
 2. Provide appropriate accessor & mutator methods to Rectangle class.
 3. Provide methods to calculate area & to display all information of Rectangle.
 4. Design different classTestRectangle class in a separate source file, which will contain main method.  From   this  main   method,  create  5  Rectangle  objects  by   taking  all   necessary information from the user and calculate respective area of rectangle objects and display it.
# Output
## 1
Enter length of rectangle: 12
Enter breadth of rectangle: 10
Area of Rectangle = 120
Perimeter of Rectangle = 44
## 2
Enter length of rectangle: 15
Enter breadth of rectangle: 7
Area of Rectangle = 105
Perimeter of Rectangle = 44
